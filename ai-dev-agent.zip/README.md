# AI Multi-Agent Dev System

## 🚀 Overview
This project implements a multi-agent AI system for automated software development.

## 🧠 Features
- Task Planning Agent
- Code Generation Agent
- Code Review Agent
- Self-healing Fix Agent

## 🔄 Workflow
Requirement → Planning → Coding → Review → Fix → Output

## ⚙️ Run
```bash
pip install -r requirements.txt
python main.py
```
