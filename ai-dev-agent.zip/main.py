from core.orchestrator import run_pipeline

if __name__ == "__main__":
    requirement = input("Enter your requirement:\n")
    result = run_pipeline(requirement)

    with open("output.py", "w") as f:
        f.write(result)

    print("\n✅ Final code saved to output.py")
