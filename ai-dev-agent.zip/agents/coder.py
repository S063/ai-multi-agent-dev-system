from utils.llm import call_llm

def generate_code(task):
    prompt = f"""
    Write Python code for the following task:

    {task}

    Include comments and keep it runnable.
    """
    return call_llm(prompt)
