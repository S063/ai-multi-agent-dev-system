from utils.llm import call_llm

def plan_task(requirement):
    prompt = f"""
    Break down the following requirement into development tasks:

    Requirement:
    {requirement}

    Output as a numbered list.
    """
    return call_llm(prompt)
