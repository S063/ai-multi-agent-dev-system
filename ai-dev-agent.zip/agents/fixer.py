from utils.llm import call_llm

def fix_code(code, review):
    prompt = f"""
    Fix the code based on review feedback.

    Code:
    {code}

    Review:
    {review}

    Output improved code only.
    """
    return call_llm(prompt)
