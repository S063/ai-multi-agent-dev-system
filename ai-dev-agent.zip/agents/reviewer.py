from utils.llm import call_llm

def review_code(code):
    prompt = f"""
    Review the following code and find bugs or improvements:

    {code}

    Output issues clearly.
    """
    return call_llm(prompt)
