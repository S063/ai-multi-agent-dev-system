from agents.planner import plan_task
from agents.coder import generate_code
from agents.reviewer import review_code
from agents.fixer import fix_code

def run_pipeline(requirement):
    print("🧠 Planning...")
    tasks = plan_task(requirement)
    print(tasks)

    final_code = ""

    for task in tasks.split("\n"):
        if not task.strip():
            continue

        print(f"\n⚙️ Task: {task}")

        code = generate_code(task)
        print("\n💻 Generated Code:\n", code)

        review = review_code(code)
        print("\n🔍 Review:\n", review)

        fixed = fix_code(code, review)
        print("\n🔧 Fixed Code:\n", fixed)

        final_code += "\n\n" + fixed

    return final_code
